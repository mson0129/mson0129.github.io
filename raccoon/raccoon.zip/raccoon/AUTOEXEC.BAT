@echo off
cd ppk
ppk.exe